package group_17.nightclubapp.com.menu

class Menu {

    val clubId : String? = null
    val items : HashMap<String, Any>? = null

}